export const proxy = 'https://cors-anywhere.herokuapp.com/';
//export const key = '43b264d46dbb4e988df1e2a5190e4b37';
export const key = '8e0c29d9d695f8bf614ae49d4053c4ed';
//export const key = 'bc4324fb820e928d3d245ccc36baabff';